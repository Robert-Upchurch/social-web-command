_Stills / 04_CTI_Marine_Travel
-------------------------------------------------
This folder is part of the Social & Web Command vault.
Place final _Stills assets for the 04_CTI_Marine_Travel brand here.

Indexed by:
  https://robert-upchurch.github.io/social-web-command/

Source-of-truth rules:
  _Masters       = final approved video masters (mp4/mov)
  _Scripts       = video & post scripts (docx/md)
  _Stills        = marketing photos, logos, graphics
  _Voiceovers    = ElevenLabs exports (.mp3/.wav)
  _Music         = Suno tracks (.mp3/.wav)
  _Raw_Working   = links/notes for working files in Frame.io / Adobe Express

Do NOT store working edits or review files here \u2014 those stay in Frame.io.
