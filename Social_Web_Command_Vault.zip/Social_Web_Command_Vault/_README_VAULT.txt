Social & Web Command \u2014 Master Vault
==========================================
CTI Group Worldwide Services, Inc.

Hybrid storage model:
  - Working video edits and review cycles  -> Frame.io
  - Final approved video masters            -> _Masters/
  - Video scripts (docx/md)                 -> _Scripts/
  - Marketing stills (photos/graphics)      -> _Stills/
  - AI voiceovers (ElevenLabs)              -> _Voiceovers/
  - AI music tracks (Suno)                  -> _Music/
  - Frame.io / Adobe Express working files  -> _Raw_Working/ (link notes only)

Six brands:
  01_J1_Division
  02_UNO_Uniforms_Number_One
  03_Baron_Promotions
  04_CTI_Marine_Travel
  05_CTI_Group
  06_CTI_Properties

Indexed live by the Social & Web Command hub:
  https://robert-upchurch.github.io/social-web-command/

Place this entire folder at:
  OneDrive / CTI Group / Social_Web_Command_Vault
